(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const format = (n) => {
    if (n < 1000) return Math.floor(n).toLocaleString("en-US");
    const units = ["K", "M", "B", "T", "Qa", "Qi"];
    let value = n, index = -1;
    while (value >= 1000 && index < units.length - 1) { value /= 1000; index++; }
    return value.toFixed(value >= 100 ? 0 : value >= 10 ? 1 : 2) + units[index];
  };

  const buildings = [
    { id:"bakery", name:"Tiny Bakery", description:"A small shop baking cookies around the clock.", baseCost:15, cps:0.2, icon:"🏠", image:"assets/tiny-bakery.png" },
    { id:"farm", name:"Cookie Farm", description:"Grow the ingredients for your growing empire.", baseCost:100, cps:1.2, icon:"🌾", image:"assets/cookie-farm.png" },
    { id:"oven", name:"Royal Oven", description:"A royal oven with a serious baking capacity.", baseCost:600, cps:7, icon:"🔥", image:"assets/royal-oven.png" },
    { id:"factory", name:"Cookie Factory", description:"Mass production for a hungry kingdom.", baseCost:3500, cps:35, icon:"🏭", image:"assets/cookie-factory.png" },
    { id:"mine", name:"Cookie Mine", description:"Dig deep for rare baking ingredients.", baseCost:18000, cps:160, icon:"⛏️", image:"assets/cookie-mine.png" },
    { id:"generator", name:"Enchanted Generator", description:"A magical source of endless bakery energy.", baseCost:95000, cps:850, icon:"✨", image:"assets/enchanted-generator.png" }
  ];
  const upgrades = [
    { id:"strongHands", name:"Strong Baker's Hands", description:"Double your cookies per click.", cost:50, icon:"✊", type:"click", multiplier:2 },
    { id:"royalRecipe", name:"Royal Recipe", description:"Increase all building production by 25%.", cost:250, icon:"📜", type:"production", multiplier:1.25 },
    { id:"goldenTouch", name:"Golden Touch", description:"Double your cookies per click again.", cost:1200, icon:"👑", type:"click", multiplier:2 },
    { id:"efficientOvens", name:"Efficient Ovens", description:"Increase all building production by 50%.", cost:5000, icon:"🔥", type:"production", multiplier:1.5 }
  ];

  const state = {
    cookies: 0, totalBaked: 0, cps: 0, clickPower: 1, empireLevel: 1,
    kingdom: "Your Kingdom", owned: Object.fromEntries(buildings.map(b => [b.id, 0])),
    purchasedUpgrades: [], productionMultiplier: 1, lastTick: Date.now()
  };

  const els = {
    home: $("homeView"), game: $("cookieEmperorView"), cookieCount: $("cookieCount"),
    cpsCount: $("cpsCount"), empireLevel: $("empireLevel"), progressText: $("levelProgressText"),
    progressFill: $("levelProgressFill"), clickPower: $("clickPower"), kingdomTitle: $("kingdomTitle"),
    recordKingdom: $("recordKingdom"), recordBuildings: $("recordBuildings"), recordBaked: $("recordBaked"),
    buildingList: $("buildingList"), upgradeList: $("upgradeList"), buildingCount: $("buildingCount"),
    stage: $("cookieStage"), toast: $("gameToast"), modal: $("settingsModal"), nameInput: $("kingdomNameInput")
  };

  function isGameRoute() { return location.hash.toLowerCase().startsWith("#cookie-emperor"); }
  function route() {
    const game = isGameRoute();
    els.home.hidden = game;
    els.game.hidden = !game;
    $("siteFooter").hidden = game;
    document.title = game ? "Cookie Emperor — PIXAFORGE" : "PIXAFORGE — Forge Your Experience";
    if (game) render();
    window.scrollTo({ top: 0, behavior: "instant" });
  }

  function recalculateCps() {
    state.cps = buildings.reduce((sum, b) => sum + state.owned[b.id] * b.cps, 0) * state.productionMultiplier;
  }
  function costOf(building) {
    return Math.floor(building.baseCost * Math.pow(1.15, state.owned[building.id]));
  }
  function showToast(message) {
    els.toast.textContent = message;
    els.toast.classList.add("show");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => els.toast.classList.remove("show"), 1700);
  }
  function renderBuildings() {
    els.buildingList.innerHTML = buildings.map(b => {
      const cost = costOf(b), owned = state.owned[b.id];
      return `<article class="building-card">
        <div class="building-art"><img src="${b.image}" alt="" onerror="this.style.display='none';this.nextElementSibling.hidden=false"><span class="building-fallback" hidden>${b.icon}</span></div>
        <div class="building-details"><div class="building-topline"><strong>${b.name}</strong><span class="building-owned">× ${owned}</span></div>
          <p>${b.description}</p><div class="building-bottom"><span class="building-cost">🍪 ${format(cost)}</span>
          <button class="buy-button building-buy" data-buy="${b.id}" ${state.cookies < cost ? "disabled" : ""}>BUY</button></div></div></article>`;
    }).join("");
    els.buildingList.querySelectorAll("[data-buy]").forEach(btn => btn.addEventListener("click", () => buyBuilding(btn.dataset.buy)));
    els.buildingCount.textContent = buildings.reduce((s,b) => s + state.owned[b.id], 0);
  }
  function renderUpgrades() {
    const available = upgrades.filter(u => !state.purchasedUpgrades.includes(u.id));
    if (!available.length) {
      els.upgradeList.innerHTML = '<p class="modal-note">All currently available upgrades have been purchased. More royal research is coming.</p>';
      return;
    }
    els.upgradeList.innerHTML = available.map(u => `<div class="upgrade-item"><div class="upgrade-icon">${u.icon}</div><div class="upgrade-info"><strong>${u.name}</strong><small>${u.description}</small></div><button class="buy-button" data-upgrade="${u.id}" ${state.cookies < u.cost ? "disabled" : ""}>🍪 ${format(u.cost)}</button></div>`).join("");
    els.upgradeList.querySelectorAll("[data-upgrade]").forEach(btn => btn.addEventListener("click", () => buyUpgrade(btn.dataset.upgrade)));
  }
  function render() {
    recalculateCps();
    els.cookieCount.textContent = format(state.cookies);
    els.cpsCount.textContent = format(state.cps);
    els.empireLevel.textContent = state.empireLevel;
    els.clickPower.textContent = format(state.clickPower);
    els.kingdomTitle.textContent = state.kingdom.toUpperCase();
    els.recordKingdom.textContent = state.kingdom;
    els.recordBuildings.textContent = buildings.reduce((s,b) => s + state.owned[b.id], 0);
    els.recordBaked.textContent = format(state.totalBaked);
    const target = state.empireLevel * 100;
    const progress = Math.min(100, state.totalBaked / target * 100);
    els.progressText.textContent = `${format(state.totalBaked)} / ${format(target)}`;
    els.progressFill.style.width = `${progress}%`;
    renderBuildings();
    renderUpgrades();
  }
  function addCookies(amount) {
    if (!Number.isFinite(amount) || amount <= 0) return;
    state.cookies += amount;
    state.totalBaked += amount;
    while (state.totalBaked >= state.empireLevel * 100) state.empireLevel++;
    render();
  }
  function bake(event) {
    addCookies(state.clickPower);
    const rect = els.stage.getBoundingClientRect();
    const x = event && event.clientX ? event.clientX - rect.left : rect.width / 2;
    const y = event && event.clientY ? event.clientY - rect.top : rect.height / 2;
    const number = document.createElement("span");
    number.className = "floating-number";
    number.textContent = `+${format(state.clickPower)}`;
    number.style.left = `${Math.max(8, Math.min(rect.width - 65, x))}px`;
    number.style.top = `${Math.max(8, y)}px`;
    els.stage.appendChild(number);
    setTimeout(() => number.remove(), 850);
    els.stage.classList.remove("shake");
    void els.stage.offsetWidth;
    els.stage.classList.add("shake");
  }
  function buyBuilding(id) {
    const building = buildings.find(b => b.id === id);
    if (!building) return;
    const cost = costOf(building);
    if (state.cookies < cost) return;
    state.cookies -= cost;
    state.owned[id]++;
    recalculateCps();
    showToast(`${building.name} added to your empire!`);
    render();
  }
  function buyUpgrade(id) {
    const upgrade = upgrades.find(u => u.id === id);
    if (!upgrade || state.purchasedUpgrades.includes(id) || state.cookies < upgrade.cost) return;
    state.cookies -= upgrade.cost;
    state.purchasedUpgrades.push(id);
    if (upgrade.type === "click") state.clickPower *= upgrade.multiplier;
    if (upgrade.type === "production") state.productionMultiplier *= upgrade.multiplier;
    showToast(`${upgrade.name} unlocked!`);
    render();
  }
  function saveKingdomName() {
    const name = els.nameInput.value.trim().replace(/[<>]/g, "").slice(0, 24);
    if (!name) { showToast("Enter a kingdom name first."); return; }
    state.kingdom = name;
    els.modal.hidden = true;
    render();
    showToast(`Welcome to ${name}!`);
  }
  function setupMobileTabs() {
    document.querySelectorAll(".mobile-tab").forEach(tab => tab.addEventListener("click", () => {
      document.querySelectorAll(".mobile-tab").forEach(t => t.classList.toggle("active", t === tab));
      const shop = $("shopPanel"), center = document.querySelector(".empire-center");
      if (window.innerWidth <= 700) {
        shop.classList.toggle("mobile-hidden", tab.dataset.panel !== "shopPanel");
        center.classList.toggle("mobile-hidden", tab.dataset.panel !== "upgradePanel");
      }
    }));
  }

  $("giantCookie").addEventListener("click", bake);
  $("settingsButton").addEventListener("click", () => { els.nameInput.value = state.kingdom; els.modal.hidden = false; });
  $("renameKingdomButton").addEventListener("click", () => { els.nameInput.value = state.kingdom; els.modal.hidden = false; });
  $("closeSettings").addEventListener("click", () => els.modal.hidden = true);
  $("saveKingdomName").addEventListener("click", saveKingdomName);
  els.nameInput.addEventListener("keydown", e => { if (e.key === "Enter") saveKingdomName(); });
  $("gameHomeButton").addEventListener("click", () => location.hash = "home");
  $("mobileMenuButton").addEventListener("click", () => {
    const nav = $("mainNav"), open = nav.classList.toggle("open");
    $("mobileMenuButton").setAttribute("aria-expanded", String(open));
  });
  document.querySelectorAll("[data-home-link]").forEach(link => link.addEventListener("click", () => $("mainNav").classList.remove("open")));
  window.addEventListener("hashchange", route);
  window.addEventListener("resize", () => {
    if (window.innerWidth > 700) {
      $("shopPanel").classList.remove("mobile-hidden");
      document.querySelector(".empire-center").classList.remove("mobile-hidden");
    }
  });

  // Prototype production loop. This is intentionally session-only until secure accounts/cloud saves are connected.
  setInterval(() => {
    if (!isGameRoute() || state.cps <= 0) return;
    const elapsed = Math.min(2, (Date.now() - state.lastTick) / 1000);
    state.lastTick = Date.now();
    if (elapsed > 0) addCookies(state.cps * elapsed);
  }, 1000);
  $("year").textContent = new Date().getFullYear();
  setupMobileTabs();
  route();
})();