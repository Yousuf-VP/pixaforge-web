(() => {
  'use strict';
  const catalog = [
    {id:'bakery',name:'Tiny Bakery',icon:'🏠',desc:'A little shop with a big ambition.',cost:15,cps:0.2,unlock:0},
    {id:'farm',name:'Cookie Farm',icon:'🌾',desc:'Grow ingredients for your empire.',cost:100,cps:1,unlock:50},
    {id:'oven',name:'Royal Oven',icon:'🔥',desc:'A royal oven that never rests.',cost:650,cps:5,unlock:300},
    {id:'factory',name:'Cookie Factory',icon:'🏭',desc:'Mass production for the kingdom.',cost:4000,cps:25,unlock:1800},
    {id:'mine',name:'Cookie Mine',icon:'⛏️',desc:'Dig deep for delicious ingredients.',cost:18000,cps:100,unlock:9000},
    {id:'magic',name:'Enchanted Generator',icon:'🔮',desc:'Magic turns possibility into pastries.',cost:90000,cps:450,unlock:45000}
  ];
  const upgrades = [
    {id:'golden-touch',name:'Golden Touch',icon:'✨',desc:'Double cookies earned per click.',cost:50,apply:s=>s.clickPower*=2},
    {id:'gloves',name:'Royal Baker Gloves',icon:'🧤',desc:'Add 3 cookies to every click.',cost:250,apply:s=>s.clickPower+=3},
    {id:'swift-hands',name:'Swift Hands',icon:'⚡',desc:'Double your current click power.',cost:1500,apply:s=>s.clickPower*=2}
  ];
  const state={cookies:0,clickPower:1,totalClicks:0,totalBaked:0,owned:Object.fromEntries(catalog.map(x=>[x.id,0])),bought:[],kingdom:'Cookie Kingdom',last:Date.now()};
  const $=id=>document.getElementById(id);
  const fmt=n=>n>=1e12?(n/1e12).toFixed(2)+'T':n>=1e9?(n/1e9).toFixed(2)+'B':n>=1e6?(n/1e6).toFixed(2)+'M':n>=1e3?(n/1e3).toFixed(1)+'K':Math.floor(n).toLocaleString('en-US');
  const production=()=>catalog.reduce((v,b)=>v+state.owned[b.id]*b.cps,0);
  const cost=b=>Math.floor(b.cost*Math.pow(1.15,state.owned[b.id]));
  const totalOwned=()=>Object.values(state.owned).reduce((a,b)=>a+b,0);
  const level=()=>1+Math.floor(Math.sqrt(state.totalBaked/100));
  function toast(msg){const el=document.createElement('div');el.className='toast';el.textContent=msg;$('toasts').append(el);setTimeout(()=>el.remove(),2500)}
  function floating(amount){const el=document.createElement('span');el.className='float-number';el.textContent='+'+fmt(amount);el.style.left=(34+Math.random()*32)+'%';el.style.top=(38+Math.random()*18)+'%';$('floatLayer').append(el);setTimeout(()=>el.remove(),900)}
  function earn(amount,click=false){state.cookies+=amount;state.totalBaked+=amount;if(click)floating(amount);renderStats()}
  function clickCookie(){earn(state.clickPower,true);state.totalClicks++;$('totalClicks').textContent=fmt(state.totalClicks);$('cookie').classList.add('clicked');setTimeout(()=>$('cookie').classList.remove('clicked'),100)}
  function buyBuilding(id){const b=catalog.find(x=>x.id===id),price=cost(b);if(state.cookies<price)return;state.cookies-=price;state.owned[id]++;toast(b.name+' purchased!');render()}
  function buyUpgrade(id){const u=upgrades.find(x=>x.id===id);if(!u||state.bought.includes(id)||state.cookies<u.cost)return;state.cookies-=u.cost;u.apply(state);state.bought.push(id);toast(u.name+' unlocked!');render()}
  function renderStats(){const lvl=level(),start=(lvl-1)**2*100,end=lvl**2*100;$('balance').textContent=fmt(state.cookies);$('cps').textContent=fmt(production());$('level').textContent=lvl;$('clickPower').textContent=fmt(state.clickPower);$('totalBaked').textContent=fmt(state.totalBaked);$('progressText').textContent=fmt(state.totalBaked-start)+' / '+fmt(end-start);$('progressBar').style.width=Math.min(100,(state.totalBaked-start)/(end-start)*100)+'%';$('ownedCount').textContent=totalOwned()+' owned'}
  function renderBuildings(){const list=$('buildings');list.innerHTML='';catalog.forEach(b=>{const owned=state.owned[b.id],price=cost(b);if(state.totalBaked<b.unlock&&owned===0)return;const card=document.createElement('article');card.className='building-card'+(state.cookies>=price?' affordable':'');card.innerHTML=`<span class="building-icon">${b.icon}</span><div class="building-meta"><b>${b.name}</b><small>${b.desc}</small><span class="cost">🍪 ${fmt(price)} · +${fmt(b.cps)}/sec</span></div><span class="owned">${owned}</span><button class="buy" ${state.cookies<price?'disabled':''}>BUY</button>`;card.querySelector('button').addEventListener('click',()=>buyBuilding(b.id));list.append(card)})}
  function renderUpgrades(){const list=$('upgrades');list.innerHTML='';upgrades.forEach(u=>{const owned=state.bought.includes(u.id),card=document.createElement('article');card.className='upgrade-card';card.innerHTML=`<span class="item-icon">${u.icon}</span><div class="item-info"><b>${u.name}</b><small>${u.desc}</small><span class="cost">${owned?'UNLOCKED':'🍪 '+fmt(u.cost)}</span></div><button class="buy" ${owned||state.cookies<u.cost?'disabled':''}>${owned?'OWNED':'BUY'}</button>`;card.querySelector('button').addEventListener('click',()=>buyUpgrade(u.id));list.append(card)})}
  function render(){renderStats();renderBuildings();renderUpgrades()}
  $('cookie').addEventListener('click',clickCookie);
  $('settings').addEventListener('click',()=>{$('kingdomName').value=state.kingdom;$('settingsDialog').showModal()});
  $('saveName').addEventListener('click',()=>{const name=$('kingdomName').value.trim();if(!name)return toast('Enter a kingdom name first.');state.kingdom=name.slice(0,24);$('kingdomTitle').textContent=state.kingdom;$('settingsDialog').close();toast('Kingdom name updated!')});
  $('reset').addEventListener('click',()=>{if(!confirm('Reset this preview? All current progress will be lost.'))return;state.cookies=0;state.clickPower=1;state.totalClicks=0;state.totalBaked=0;state.owned=Object.fromEntries(catalog.map(x=>[x.id,0]));state.bought=[];state.kingdom='Cookie Kingdom';$('kingdomTitle').textContent=state.kingdom;$('settingsDialog').close();render();toast('Preview reset.')});
  document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===t));if(t.dataset.tab==='special')$('buildings').innerHTML='<div class="recipe"><span>🎁</span><div><b>Special royal stock</b><small>Rare items and special-cookie trades are planned for a future update.</small></div><span>🔒</span></div>';else renderBuildings()}));
  document.querySelectorAll('.mobile-nav button').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.mobile-nav button').forEach(x=>x.classList.toggle('active',x===btn));document.querySelectorAll('.layout>.panel').forEach(p=>p.classList.toggle('mobile-active',p.id===btn.dataset.panel))}));
  setInterval(()=>{const now=Date.now(),elapsed=Math.min((now-state.last)/1000,2);state.last=now;const earned=production()*elapsed;if(earned>0){state.cookies+=earned;state.totalBaked+=earned;renderStats();renderBuildings();renderUpgrades()}},500);
  if(matchMedia('(max-width:700px)').matches)$('cookie-panel').classList.add('mobile-active');
  render();
})();
