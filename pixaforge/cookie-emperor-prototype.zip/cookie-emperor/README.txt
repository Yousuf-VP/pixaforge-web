COOKIE EMPEROR — PLAYABLE FRONTEND PROTOTYPE

Run: Extract the ZIP and open index.html, or open the folder in VS Code and use Live Server.

Included: classic clicker layout, giant cookie clicking, floating click numbers, currency and production counters, empire level progress, building shop, increasing building prices, click upgrades, kingdom naming, settings, reset-preview control, responsive mobile section navigation.

IMPORTANT STATUS: This is a playable frontend prototype only. Account registration/login, Supabase cloud saving, server-authoritative purchases, recipe experimentation, daily rewards and secure offline earnings are not connected yet. Progress is held in memory and resets on refresh. No LocalStorage is used.

For the intended production game, connect Supabase Auth and PostgreSQL, add RLS policies, and move authoritative currency/purchase/reward logic to secure server-side functions. Never expose the Supabase service-role key in browser code.
